# Instalace pouze programu Tracer
sudo dnf install tracer

# Instalace včetně DNF pluginu
# Netřeba explicitně instalovat balík 'tracer'
sudo dnf install dnf-plugins-extras-tracer
