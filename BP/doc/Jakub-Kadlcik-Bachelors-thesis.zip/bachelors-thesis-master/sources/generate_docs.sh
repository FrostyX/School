cd doc
make help        # Pro výběr cílového formátu
make <target>
